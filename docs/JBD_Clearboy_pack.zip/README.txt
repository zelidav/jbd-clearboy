JBD x Boutiq - Clearboy programme
Manufacturing hand-off pack

  spec/JBD_Clearboy_spec.pdf   Rev A, frit-rolled - read this first. Dimensions,
                               dimensioned closeups, the survey, decoration, and the
                               bench process with its QC hold points.
  spec/JBD_Clearboy_spec_RevB.pdf
                               Rev B, no frit. Same geometry, same dimensions, same
                               decals and QC - the frit is left off and the linework
                               and marbles go straight onto the fumed body. Build to
                               ONE of these two sheets, not a mixture.
  spec/dimensions.png          the dimensional survey of the original piece. The piece
                               photographed is the frit-rolled original either way.
  spec/detail/*.png            dimensioned closeups, Rev A
  spec/detail_RevB/*.png       the same closeups, Rev B
  cad/*.step                   solid B-rep - the reference geometry
  cad/*.stl                    meshes - 3D print, mould master, wax pattern
  box/*.png                    the collaboration box with the pieces seated
  JBD_x_Boutiq.pdf             the leave-behind, box plate by plate

STEP is the reference. The meshes are for print and mould work only.
Wall thickness on the hammer is inferred, not measured - confirm with calipers
before any tooling. Figures are in millimetres.
