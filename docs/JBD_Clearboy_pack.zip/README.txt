JBD x Boutiq - Clearboy programme
Manufacturing hand-off pack

  spec/JBD_Clearboy_spec.pdf   the spec sheet - read this first. Dimensions,
                               dimensioned closeups, the survey, decoration, and the
                               bench process with its QC hold points.
  spec/dimensions.png          the dimensional survey of the original piece
  spec/detail/*.png            dimensioned closeups, full resolution
  cad/*.step                   solid B-rep - the reference geometry
  cad/*.stl                    meshes - 3D print, mould master, wax pattern
  box/*.png                    the collaboration box with the pieces seated
  JBD_x_Boutiq.pdf             the leave-behind, box plate by plate

STEP is the reference. The meshes are for print and mould work only.
Wall thickness on the hammer is inferred, not measured - confirm with calipers
before any tooling. Figures are in millimetres.
